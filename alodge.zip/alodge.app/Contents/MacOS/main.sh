#!/bin/bash

clear

open -a "Google Chrome" "http://www.a-lodge.com"

clear
