#!/bin/bash

clear

cd ~/Desktop/alodge.app/Contents/MacOS/ && nohup php -S localhost:8888

clear

open -a "Google Chrome" "http://localhost:8888"

clear
