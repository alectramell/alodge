<?php
	$xtitle = 'Adventure Lodge | Boulder, CO';
?>
<html>
<head>
<title>
<?php echo $xtitle; ?>
</title>
<link type="text/css" rel="stylesheet" href="css/main.css">
</head>
<body>

<img id="logo" src="img/logo.png">

</body>
</html>
